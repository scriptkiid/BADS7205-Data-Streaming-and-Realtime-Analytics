Create instance
- Create EC2
- Add security group
- Keep .pem file

Install JAVA
- https://www.digitalocean.com/community/tutorials/how-to-install-java-with-apt-on-ubuntu-18-04
- sudo apt-get update
- sudo apt-get -y install default-jdk
- java -version
- javac -version

Download Kafka
- wget https://downloads.apache.org/kafka/2.8.0/kafka_2.13-2.8.0.tgz
- tar -xzf kafka_2.13-2.8.0.tgz
- cd kafka_2.13-2.8.0

SSH to AWS EC2
- https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/AccessingInstancesLinux.html

Kafka tutorials
https://kafka.apache.org/quickstart

Start zookeeper
- bin/zookeeper-server-start.sh config/zookeeper.properties
- Troubleshoot:
    - java.io.IOException: No snapshot found, but there are log entries. Something is broken!
        rm -rf /tmp/zookeeper/*

Start Kafka
- Edit server.properties
    - listeners=PLAINTEXT://ec2-18-141-180-79.ap-southeast-1.compute.amazonaws.com:9092
- bin/kafka-server-start.sh config/server.properties
- Troubleshoot:
    - Failed to acquire lock on file .lock in /tmp/kafka-logs. A Kafka instance in another process or thread is using this directory.
        rm -rf /tmp/kafka-logs

Create topic
- bin/kafka-topics.sh --create --topic quickstart-events --bootstrap-server localhost:9092
- bin/kafka-topics.sh --describe --topic quickstart-events --bootstrap-server localhost:9092

Producer
- bin/kafka-console-producer.sh --topic quickstart-events --bootstrap-server ec2-XX-XXX-XXX-XX.ap-southeast-1.compute.amazonaws.com:9092

Consumer
- bin/kafka-console-consumer.sh --topic quickstart-events --from-beginning --bootstrap-server ec2-XX-XXX-XXX-XX.ap-southeast-1.compute.amazonaws.com:9092

VENV
- https://medium.com/@chanisarauttamawetin/virtual-environments-in-python-%E0%B9%83%E0%B8%8A%E0%B9%89%E0%B8%87%E0%B9%88%E0%B8%B2%E0%B8%A2%E0%B9%86%E0%B8%81%E0%B8%B1%E0%B8%9A-vscode-4d23d29dd57e
- venv\Scripts\activate

Python:
- https://towardsdatascience.com/kafka-python-explained-in-10-lines-of-code-800e3e07dad1
